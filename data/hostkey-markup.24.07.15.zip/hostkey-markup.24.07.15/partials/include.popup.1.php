<div class="b-modal">
    <div class="tab-list b-modal__tabs js-tab-wrapper">
        <div class="tab-list__container">
            <div class="tab-list__item b-modal__tabs-item current js-tab" data-tab="1">
                <div class="b-modal__tabs-item-price">REGISTER</div>
                <div class="b-modal__tabs-item-price"><span class="b-modal__tabs-item-price-big">€7.99</span>/year</div>
            </div>
            <div class="tab-list__item b-modal__tabs-item js-tab" data-tab="2">
                <div class="b-modal__tabs-item-price">REGISTER</div>
                <div class="b-modal__tabs-item-price"><span class="b-modal__tabs-item-price-big">€4.99</span>/year</div>
            </div>
            <div class="tab-list__item b-modal__tabs-item js-tab" data-tab="3">
                <div class="b-modal__tabs-item-price">OWNER CHANGE</div>
                <div class="b-modal__tabs-item-price"><span class="b-modal__tabs-item-price-big">€7.99</span>/year</div>
            </div>
            <div class="tab-list__item b-modal__tabs-item js-tab" data-tab="4">
                <div class="b-modal__tabs-item-price">RESTORATIO</div>
                <div class="b-modal__tabs-item-price"><span class="b-modal__tabs-item-price-big">€7.99</span>/year</div>
            </div>
        </div>
        <div class="tab-list__container">
            <div class="tab-list__content b-modal__tabs-content current js-tab-content" data-tab="1">
                <div class="search-bar">
                    <input class="b-input search-bar__input" type="text" placeholder="Enter your domain .NET name here"><!--
                    --><a class="b-submit search-bar__submit" href="#"> search</a>
                </div>
                <table class="b-modal__tabs-content-table">
                    <tr class="b-modal__tabs-content-table-row">
                        <td class="b-modal__tabs-content-table-cell">Domain booking period</td>
                        <td class="b-modal__tabs-content-table-cell">1 year</td>
                    </tr>
                    <tr class="b-modal__tabs-content-table-row">
                        <td class="b-modal__tabs-content-table-cell">Renewal period</td>
                        <td class="b-modal__tabs-content-table-cell">1 year</td>
                    </tr>
                </table>
                <div class="b-modal__tabs-content-text">
                    The renewal can be done from the Control Panel via the "my products" section.
                    If the domain name is not renewed in time, it will be in the redemption period (40 days) during which the owner will have the possibility to reactivate it by making a request to support. Once the redemption period has expired, the domain name will be definitely deleted and will be available again.
                </div>
            </div>
            <div class="tab-list__content b-modal__tabs-content js-tab-content" data-tab="2">Content area 2</div>
            <div class="tab-list__content b-modal__tabs-content js-tab-content" data-tab="3">Content area 3</div>
            <div class="tab-list__content b-modal__tabs-content js-tab-content" data-tab="4">Content area 4</div>
        </div>
    </div>
</div>
