<div class="b-dedicated__hide-block-close js-close">
    <span class="b-icon b-dedicated__hide-block-close-image"></span>
    <span class="b-dedicated__hide-block-close-text">hide</span>
</div>
<div class="b-dedicated__item-content b-dedicated__item-content_padding-top_yes dedicated-item-content">
    <div class="b-dedicated__box">
        <h3 class="b-dedicated__title b-dedicated__title_upline_yes">Visualisation nodes</h3>

        <div class="b-dedicated__description">
            HOSTKEY offers own dedicated and virtual servers in various Datacenters in Moscow, Russia.
            We are first hands for offshore Dedicated servers in Russia since 2008, managing 600+ servers here with 20+
            international resellers. Virtually any server configuration could be provided to our customers. We offer
            full range of modern and stock servers for every task. You could lease Cisco network equipment or collocate
            your own servers in Moscow.
        </div>
    </div>

    <table class="dedicated-item-content__table">
        <tr class="dedicated-item-content__row dedicated-item-content__row_title_yes">
            <td class="dedicated-item-content__cell"></td>
            <td class="dedicated-item-content__cell">processor</td>
            <td class="dedicated-item-content__cell">memory</td>
            <td class="dedicated-item-content__cell">hard drive</td>
            <td class="dedicated-item-content__cell">hardwear raid</td>
            <td class="dedicated-item-content__cell">vlan</td>
            <td class="dedicated-item-content__cell">impi</td>
            <td class="dedicated-item-content__cell">free bonus</td>
            <td class="dedicated-item-content__cell">monthly (€)</td>
        </tr>
        <tr class="dedicated-item-content__row">
            <td class="dedicated-item-content__cell">
                <span class="dedicated-item-content__title">Video streaming</span>
                <span class="dedicated-item-content__subtitle">For small projects</span>
            </td>
            <td class="dedicated-item-content__cell">
                <div class="dedicate-select-red dedicate-select-red__proc_yes js-drop-block">
                    <div class="dedicate-select-red__value is-value">CoreDuo2 E6320 1.86 GHz (2 core)</div>
                    <div class="dedicate-select-red__drop is-drop">
                        <div class="dedicate-select-red__drop-item js-drop-item is-active">CoreDuo2 E6320 1.86 GHz (2 core)</div>
                        <div class="dedicate-select-red__drop-item js-drop-item">CoreDuo2 E6320 2.86 GHz (4 core)</div>
                        <div class="dedicate-select-red__drop-item js-drop-item">CoreDuo2 E6320 3.86 GHz (8 core)</div>
                    </div>
                </div>
            </td>
            <td class="dedicated-item-content__cell">
                <select class="dedicate-select-red js-select" name="mem-1" id="mem-1">
                    <option value="1">24 Gb</option>
                    <option value="2">128 Gb</option>
                    <option value="3">512 Gb</option>
                </select>
            </td>
            <td class="dedicated-item-content__cell">
                <select class="dedicate-select-red dedicate-select-red__hard_yes js-select" name="hard-1" id="hard-1">
                    <option value="1">2x500Gb SATA</option>
                    <option value="2">4x500Gb SATA</option>
                    <option value="3">2x2Tb SATA</option>
                </select>
            </td>
            <td class="dedicated-item-content__cell">
                <label class="fake-checkbox-label">
                    <span class="fake-checkbox-label__box js-check"></span>
                    <input class="hidden-input" name="222" type="checkbox">
                </label>
            </td>
            <td class="dedicated-item-content__cell">
                <select class="dedicate-select-red js-select" name="vlan-1" id="vlan-1">
                    <option value="1">100 Mbps</option>
                    <option value="2">200 Mbps</option>
                    <option value="3">50 Mbps</option>
                </select>
            </td>
            <td class="dedicated-item-content__cell">
                <label class="fake-checkbox-label">
                    <span class="fake-checkbox-label__box js-check"></span>
                    <input class="hidden-input" name="1111" type="checkbox">
                </label>
            </td>
            <td class="dedicated-item-content__cell">
                <span class="dedicate-item-content__text">20 IP, traffic, cPanel, Windows</span>
            </td>
            <td class="dedicated-item-content__cell">
                <a class="b-submit dedicated-item-content__submit" href="#">1650.65</a>
            </td>
        </tr>
        <tr class="dedicated-item-content__row">
            <td class="dedicated-item-content__cell">
                <span class="dedicated-item-content__title">First server</span>
                <span class="dedicated-item-content__subtitle">For small projects</span>
            </td>
            <td class="dedicated-item-content__cell">
                <div class="dedicate-select-red dedicate-select-red__proc_yes js-drop-block">
                    <div class="dedicate-select-red__value is-value">CoreDuo2 E6320 1.86 GHz (2 core)</div>
                    <div class="dedicate-select-red__drop is-drop">
                        <div class="dedicate-select-red__drop-item js-drop-item is-active">CoreDuo2 E6320 1.86 GHz (2 core)</div>
                        <div class="dedicate-select-red__drop-item js-drop-item">CoreDuo2 E6320 2.86 GHz (4 core)</div>
                        <div class="dedicate-select-red__drop-item js-drop-item">CoreDuo2 E6320 3.86 GHz (8 core)</div>
                    </div>
                </div>
            </td>
            <td class="dedicated-item-content__cell">
                <select class="dedicate-select-red js-select" name="mem-1" id="mem-1">
                    <option value="1">24 Gb</option>
                    <option value="2">128 Gb</option>
                    <option value="3">512 Gb</option>
                </select>
            </td>
            <td class="dedicated-item-content__cell">
                <select class="dedicate-select-red dedicate-select-red__hard_yes js-select" name="hard-1" id="hard-1">
                    <option value="1">2x500Gb SATA</option>
                    <option value="2">4x500Gb SATA</option>
                    <option value="3">2x2Tb SATA</option>
                </select>
            </td>
            <td class="dedicated-item-content__cell">
                <label class="fake-checkbox-label">
                    <span class="fake-checkbox-label__box js-check"></span>
                    <input class="hidden-input" name="222" type="checkbox">
                </label>
            </td>
            <td class="dedicated-item-content__cell">
                <select class="dedicate-select-red js-select" name="vlan-1" id="vlan-1">
                    <option value="1">100 Mbps</option>
                    <option value="2">200 Mbps</option>
                    <option value="3">50 Mbps</option>
                </select>
            </td>
            <td class="dedicated-item-content__cell">
                <label class="fake-checkbox-label">
                    <span class="fake-checkbox-label__box js-check"></span>
                    <input class="hidden-input" name="1111" type="checkbox">
                </label>
            </td>
            <td class="dedicated-item-content__cell">
                <span class="dedicate-item-content__text">20 IP, traffic, cPanel, Windows, VPS, premium SLA, super backup</span>
            </td>
            <td class="dedicated-item-content__cell">
                <a class="b-submit dedicated-item-content__submit" href="#">1650.65</a>
            </td>
        </tr>
        <tr class="dedicated-item-content__row">
            <td class="dedicated-item-content__cell">
                <span class="dedicated-item-content__title">Extra power</span>
                <span class="dedicated-item-content__subtitle">For small projects</span>
            </td>
            <td class="dedicated-item-content__cell">
                <div class="dedicate-select-red dedicate-select-red__proc_yes js-drop-block">
                    <div class="dedicate-select-red__value is-value">CoreDuo2 E6320 1.86 GHz (2 core)</div>
                    <div class="dedicate-select-red__drop is-drop">
                        <div class="dedicate-select-red__drop-item js-drop-item is-active">CoreDuo2 E6320 1.86 GHz (2 core)</div>
                        <div class="dedicate-select-red__drop-item js-drop-item">CoreDuo2 E6320 2.86 GHz (4 core)</div>
                        <div class="dedicate-select-red__drop-item js-drop-item">CoreDuo2 E6320 3.86 GHz (8 core)</div>
                    </div>
                </div>
            </td>
            <td class="dedicated-item-content__cell">
                <select class="dedicate-select-red js-select" name="mem-1" id="mem-1">
                    <option value="1">24 Gb</option>
                    <option value="2">128 Gb</option>
                    <option value="3">512 Gb</option>
                </select>
            </td>
            <td class="dedicated-item-content__cell">
                <select class="dedicate-select-red dedicate-select-red__hard_yes js-select" name="hard-1" id="hard-1">
                    <option value="1">2x500Gb SATA</option>
                    <option value="2">4x500Gb SATA</option>
                    <option value="3">2x2Tb SATA</option>
                </select>
            </td>
            <td class="dedicated-item-content__cell">
                <label class="fake-checkbox-label">
                    <span class="fake-checkbox-label__box js-check"></span>
                    <input class="hidden-input" name="222" type="checkbox">
                </label>
            </td>
            <td class="dedicated-item-content__cell">
                <select class="dedicate-select-red js-select" name="vlan-1" id="vlan-1">
                    <option value="1">100 Mbps</option>
                    <option value="2">200 Mbps</option>
                    <option value="3">50 Mbps</option>
                </select>
            </td>
            <td class="dedicated-item-content__cell">
                <label class="fake-checkbox-label">
                    <span class="fake-checkbox-label__box js-check"></span>
                    <input class="hidden-input" name="1111" type="checkbox">
                </label>
            </td>
            <td class="dedicated-item-content__cell">
                <span class="dedicate-item-content__text">20 IP, traffic, cPanel, Windows</span>
            </td>
            <td class="dedicated-item-content__cell">
                <a class="b-submit dedicated-item-content__submit" href="#">1650.65</a>
            </td>
        </tr>
    </table>

</div>

<div class="b-dedicated__item-content dedicated-item-content">
<div class="b-dedicated__box">
    <h3 class="b-dedicated__title b-dedicated__title_upline_yes">configurator of Virtualisation nodes SOLUTIONS</h3>

    <div class="b-dedicated__description">
        HOSTKEY offers own dedicated and virtual servers in various Datacenters in Moscow, Russia.
        We are first hands for offshore Dedicated servers in Russia since 2008, managing 600+ servers here with 20+
        international resellers. Virtually any server configuration could be provided to our customers. We offer full
        range of modern and stock servers for every task. You could lease Cisco network equipment or collocate your own
        servers in Moscow.
    </div>
</div>

<div class="b-container">
<div class="b-dedicated__accordion b-accordion" id="scroll-box">
<h3 class="b-accordion__title"><span class="b-accordion__title-main">Hardware</span><span>Xeon E3-1230v3 4x3.3GHz</span>
</h3>

<div class="b-accordion__item">
<table class="b-dedicated__accordion-table">
<tr class="b-dedicated__accordion-table-row">
    <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">CPU</td>
    <td class="b-dedicated__accordion-table-cell js-checked">
        <label class="b-checkbox-submit">
            <span class="b-checkbox-submit__text">Xeon E3-1230v3 4x3.3GHz</span>
            <input class="js-checked-submit" name="check-01" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit">
            <span class="b-checkbox-submit__text">Core i3-4360 2x3.7GHz</span>
            <input class="js-checked-submit" name="check-01" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit">
            <span class="b-checkbox-submit__text">E3-1271v3 4x3,6Ghz</span>
            <input class="js-checked-submit" name="check-01" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit">
            <span class="b-checkbox-submit__text">E5-1650v3 6x3.7GHz</span>
            <input class="js-checked-submit" name="check-01" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit">
            <span class="b-checkbox-submit__text">E5-1660v3 8x3.0GHz</span>
            <input class="js-checked-submit" name="check-01" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit">
            <span class="b-checkbox-submit__text">2xE5-2620v3 12x2.4GHz</span>
            <input class="js-checked-submit" name="check-01" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit">
            <span class="b-checkbox-submit__text">2xE5-2630v3 16x2.4GHz</span>
            <input class="js-checked-submit" name="check-01" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit">
            <span class="b-checkbox-submit__text">2xE5-2680v3 24x2.5GHz</span>
            <input class="js-checked-submit" name="check-01" type="radio"/>
        </label>
    </td>
</tr>
<tr class="b-dedicated__accordion-table-row">
    <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">RAm</td>
    <td class="b-dedicated__accordion-table-cell js-checked">
        <label class="b-checkbox-submit b-checkbox-submit_size_70">
            <span class="b-checkbox-submit__text">512 M</span>
            <input class="js-checked-submit" name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70">
            <span class="b-checkbox-submit__text">1 GB</span>
            <input class="js-checked-submit" name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70">
            <span class="b-checkbox-submit__text">2 GB</span>
            <input class="js-checked-submit" name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70">
            <span class="b-checkbox-submit__text">4 GB</span>
            <input class="js-checked-submit" name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70">
            <span class="b-checkbox-submit__text">8 GB</span>
            <input class="js-checked-submit" name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70">
            <span class="b-checkbox-submit__text">16 GB</span>
            <input class="js-checked-submit" name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70">
            <span class="b-checkbox-submit__text">24 GB</span>
            <input class="js-checked-submit" name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70">
            <span class="b-checkbox-submit__text">32 GB</span>
            <input class="js-checked-submit" name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70">
            <span class="b-checkbox-submit__text">48 GB</span>
            <input class="js-checked-submit" name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70 disable">
            <span class="b-checkbox-submit__text">64 GB</span>
            <input class="js-checked-submit" disabled name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70 disable">
            <span class="b-checkbox-submit__text">96 GB</span>
            <input class="js-checked-submit" disabled name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70 disable">
            <span class="b-checkbox-submit__text">128 GB</span>
            <input class="js-checked-submit" disabled name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70 disable">
            <span class="b-checkbox-submit__text">192 GB</span>
            <input class="js-checked-submit" disabled name="check-02" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_70 disable">
            <span class="b-checkbox-submit__text">256 GB</span>
            <input class="js-checked-submit" disabled name="check-02" type="radio"/>
        </label>
    </td>
</tr>
<tr class="b-dedicated__accordion-table-row">
    <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">disks</td>
    <td class="b-dedicated__accordion-table-cell js-checked">
        <label class="b-checkbox-submit b-checkbox-submit_size_170">
            <span class="b-checkbox-submit__text">2 disks</span>
            <input class="js-checked-submit" name="check-03" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_170">
            <span class="b-checkbox-submit__text">4 disks</span>
            <input class="js-checked-submit" name="check-03" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_170">
            <span class="b-checkbox-submit__text">8 disks</span>
            <input class="js-checked-submit" name="check-03" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_170">
            <span class="b-checkbox-submit__text">12 disks</span>
            <input class="js-checked-submit" name="check-03" type="radio"/>
        </label><!--
                                                --><label class="b-checkbox-submit b-checkbox-submit_size_170">
            <span class="b-checkbox-submit__text">24 disks</span>
            <input class="js-checked-submit" name="check-03" type="radio"/>
        </label>
    </td>
</tr>
<tr class="b-dedicated__accordion-table-row">
    <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes"></td>
    <td class="b-dedicated__accordion-table-cell js-checked">
        <table class="table-select">
            <tr class="table-select__row">
                <td class="table-select__cell">
                    <label class="table-select__item-label" for="tbl-select-1">1 disk</label>
                    <select class="table-select__item js-select" name="tbl-select-1" id="tbl-select-1">
                        <option value="1">NONE</option>
                        <option value="2">1 Gb</option>
                        <option value="3">2 Gb</option>
                        <option value="4">4 Gb</option>
                    </select>
                </td>
                <td class="table-select__cell">
                    <label class="table-select__item-label" for="tbl-select-2">2 disk</label>
                    <select class="table-select__item js-select" name="tbl-select-2" id="tbl-select-2">
                        <option value="1">NONE</option>
                        <option value="2">1 Gb</option>
                        <option value="3">4 Gb</option>
                    </select>
                </td>
                <td class="table-select__cell">
                    <label class="table-select__item-label" for="tbl-select-3">3 disk</label>
                    <select class="table-select__item js-select" name="tbl-select-3" id="tbl-select-3">
                        <option value="1">NONE</option>
                        <option value="2">1 Gb</option>
                        <option value="3">4 Gb</option>
                    </select>
                </td>
                <td class="table-select__cell">
                    <label class="table-select__item-label" for="tbl-select-4">4 disk</label>
                    <select class="table-select__item js-select" name="tbl-select-4" id="tbl-select-4">
                        <option value="1">NONE</option>
                        <option value="2">1 Gb</option>
                        <option value="3">4 Gb</option>
                    </select>
                </td>
            </tr>
            <tr class="table-select__row">
                <td class="table-select__cell">
                    <label class="table-select__item-label" for="tbl-select-5">5 disk</label>
                    <select class="table-select__item js-select" name="tbl-select-5" id="tbl-select-5">
                        <option value="1">NONE</option>
                        <option value="2">1 Gb</option>
                        <option value="3">4 Gb</option>
                    </select>
                </td>
                <td class="table-select__cell">
                    <label class="table-select__item-label" for="tbl-select-6">6 disk</label>
                    <select class="table-select__item js-select" name="tbl-select-6" id="tbl-select-6">
                        <option value="1">NONE</option>
                        <option value="2">1 Gb</option>
                        <option value="3">4 Gb</option>
                    </select>
                </td>
                <td class="table-select__cell">
                    <label class="table-select__item-label" for="tbl-select-7">7 disk</label>
                    <select class="table-select__item js-select" name="tbl-select-7" id="tbl-select-7">
                        <option value="1">NONE</option>
                        <option value="2">1 Gb</option>
                        <option value="3">4 Gb</option>
                    </select>
                </td>
                <td class="table-select__cell">
                    <label class="table-select__item-label" for="tbl-select-8">8 disk</label>
                    <select class="table-select__item js-select" name="tbl-select-8" id="tbl-select-8">
                        <option value="1">NONE</option>
                        <option value="2">1 Gb</option>
                        <option value="3">4 Gb</option>
                    </select>
                </td>
            </tr>
            <tr class="table-select__row">
                <td class="table-select__cell" colspan="3">
                    <label class="table-select__item-label" for="tbl-select-9">RAID:</label>
                    <select class="table-select__item js-select" name="tbl-select-9" id="tbl-select-9">
                        <option value="1">LSI MegaRAID SAS 9340 (RAID 0-5)(23)</option>
                        <option value="2">1 Gb</option>
                        <option value="3">4 Gb</option>
                    </select>
                </td>
                <td class="table-select__cell">
                    <label class="table-select__item-label" for="tbl-select-10">LEVEL:</label>
                    <select class="table-select__item js-select" name="tbl-select-10" id="tbl-select-10">
                        <option value="1">No raid</option>
                        <option value="2">1 Gb</option>
                        <option value="3">4 Gb</option>
                    </select>
                </td>
            </tr>
        </table>
    </td>
</tr>
</table>
</div>
<h3 class="b-accordion__title"><span class="b-accordion__title-main">Software</span><span>W12SE(trl)/32-bit/SQL12WE (20)/MS Exchange Standard (1.50) x 1</span>
</h3>

<div class="b-accordion__item">
    <table class="b-dedicated__accordion-table">
        <tr class="b-dedicated__accordion-table-row">
            <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">OS</td>
            <td class="b-dedicated__accordion-table-cell">
                <table class="table-select">
                    <tr class="table-select__row">
                        <td class="table-select__cell table-select__cell_double_yes" colspan="2">
                            <select class="table-select__item js-select">
                                <option value="1"> Windows Server 12 Datacenter (70)</option>
                                <option value="2">1 Gb</option>
                                <option value="3">2 Gb</option>
                                <option value="4">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell">
                            <select class="table-select__item js-select">
                                <option value="1">64 BIT</option>
                                <option value="2">1 Gb</option>
                                <option value="3">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell">
                            <label class="table-select__item-label table-select__item-label_inline_yes">RDP<br>
                                Licenses</label>
                            <input class="table-select__input" type="text"/>
                            <span class="table-select__input-x">X € 3</span>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr class="b-dedicated__accordion-table-row">
            <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">MS SQL</td>
            <td class="b-dedicated__accordion-table-cell">
                <table class="table-select">
                    <tr class="table-select__row">
                        <td class="table-select__cell table-select__cell_double_yes" colspan="2">
                            <select class="table-select__item js-select">
                                <option value="1"> Windows Server 12 Datacenter (70)</option>
                                <option value="2">1 Gb</option>
                                <option value="3">2 Gb</option>
                                <option value="4">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell"></td>
                        <td class="table-select__cell"></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr class="b-dedicated__accordion-table-row">
            <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">MS Exchange
                CALs
            </td>
            <td class="b-dedicated__accordion-table-cell">
                <table class="table-select">
                    <tr class="table-select__row">
                        <td class="table-select__cell table-select__cell_double_yes" colspan="2">
                            <select class="table-select__item js-select">
                                <option value="1"> Windows Server 12 Datacenter (70)</option>
                                <option value="2">1 Gb</option>
                                <option value="3">2 Gb</option>
                                <option value="4">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell">
                            <label class="table-select__item-label table-select__item-label_inline_yes">Count</label>
                            <input class="table-select__input" type="text"/>
                            <span class="table-select__input-x">X € 2</span>
                        </td>
                        <td class="table-select__cell"></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>
<h3 class="b-accordion__title"><span class="b-accordion__title-main">Network</span><span>200Mbps unmetered (52Tb max) (140)/2 IPv4 (4)/VLAN port 100Mbps (5)/FTP Backup 1</span>
</h3>

<div class="b-accordion__item">
    <table class="b-dedicated__accordion-table">
        <tr class="b-dedicated__accordion-table-row">
            <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">traffic</td>
            <td class="b-dedicated__accordion-table-cell">
                <table class="table-select">
                    <tr class="table-select__row">
                        <td class="table-select__cell table-select__cell_double_yes" colspan="2">
                            <select class="table-select__item js-select">
                                <option value="1"> 400 Mbps unmetered (104Tb max) (210)</option>
                                <option value="2">1 Gb</option>
                                <option value="3">2 Gb</option>
                                <option value="4">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell"></td>
                        <td class="table-select__cell"></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr class="b-dedicated__accordion-table-row">
            <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">ip</td>
            <td class="b-dedicated__accordion-table-cell">
                <table class="table-select">
                    <tr class="table-select__row">
                        <td class="table-select__cell table-select__cell_double_yes" colspan="2">
                            <select class="table-select__item js-select">
                                <option value="1"> Windows Server 12 Datacenter (70)</option>
                                <option value="2">1 Gb</option>
                                <option value="3">2 Gb</option>
                                <option value="4">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell"></td>
                        <td class="table-select__cell"></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr class="b-dedicated__accordion-table-row">
            <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">vlan</td>
            <td class="b-dedicated__accordion-table-cell">
                <table class="table-select">
                    <tr class="table-select__row">
                        <td class="table-select__cell table-select__cell_double_yes" colspan="2">
                            <select class="table-select__item js-select">
                                <option value="1"> Windows Server 12 Datacenter (70)</option>
                                <option value="2">1 Gb</option>
                                <option value="3">2 Gb</option>
                                <option value="4">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell"></td>
                        <td class="table-select__cell"></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr class="b-dedicated__accordion-table-row">
            <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">ftp backup</td>
            <td class="b-dedicated__accordion-table-cell">
                <table class="table-select">
                    <tr class="table-select__row">
                        <td class="table-select__cell table-select__cell_double_yes" colspan="2">
                            <select class="table-select__item js-select">
                                <option value="1"> Windows Server 12 Datacenter (70)</option>
                                <option value="2">1 Gb</option>
                                <option value="3">2 Gb</option>
                                <option value="4">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell"></td>
                        <td class="table-select__cell"></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>
<h3 class="b-accordion__title"><span class="b-accordion__title-main">SLA</span><span>Basic SLA /Self-service</span></h3>

<div class="b-accordion__item">
    <table class="b-dedicated__accordion-table">
        <tr class="b-dedicated__accordion-table-row">
            <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">Service level
                agreement
            </td>
            <td class="b-dedicated__accordion-table-cell">
                <table class="table-select">
                    <tr class="table-select__row">
                        <td class="table-select__cell table-select__cell_double_yes" colspan="2">
                            <select class="table-select__item js-select">
                                <option value="1"> 400 Mbps unmetered (104Tb max) (210)</option>
                                <option value="2">1 Gb</option>
                                <option value="3">2 Gb</option>
                                <option value="4">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell"></td>
                        <td class="table-select__cell"></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr class="b-dedicated__accordion-table-row">
            <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">FTP Backup</td>
            <td class="b-dedicated__accordion-table-cell">
                <table class="table-select">
                    <tr class="table-select__row">
                        <td class="table-select__cell table-select__cell_double_yes" colspan="2">
                            <select class="table-select__item js-select">
                                <option value="1"> Windows Server 12 Datacenter (70)</option>
                                <option value="2">1 Gb</option>
                                <option value="3">2 Gb</option>
                                <option value="4">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell"></td>
                        <td class="table-select__cell"></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>
</div>

<div class="b-dedicated__summary" id="scroll-block">
    <div class="b-dedicated__summary-title">Your dedicated</div>
    <div class="b-dedicated__summary-price">
        <span class="b-dedicated__summary-price-value">€475.99/year</span>
        <span class="b-dedicated__summary-price-discount">12% discount, save €97.92</span>
    </div>
    <a class="b-submit b-dedicated__summary-submit" href="#">buy</a>
</div>
</div>

<div class="b-container">
    <table class="b-dedicated__accordion-table">
        <tr class="b-dedicated__accordion-table-row">
            <td class="b-dedicated__accordion-table-cell b-dedicated__accordion-table-cell_title_yes">Billing cycle
                discount:
            </td>
            <td class="b-dedicated__accordion-table-cell">
                <table class="table-select">
                    <tr class="table-select__row">
                        <td class="table-select__cell">
                            <select class="table-select__item js-select">
                                <option value="1">Monthly</option>
                                <option value="2">1 Gb</option>
                                <option value="3">2 Gb</option>
                                <option value="4">4 Gb</option>
                            </select>
                        </td>
                        <td class="table-select__cell"></td>
                        <td class="table-select__cell"></td>
                        <td class="table-select__cell"></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>
</div>

<script src="js/scroll-block.js"></script>