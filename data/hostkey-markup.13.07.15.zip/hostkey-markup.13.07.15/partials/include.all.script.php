<script src="vendors/jquery.scrollTo-1.4.13/jquery.scrollTo.min.js"></script>

<script src="vendors/checkbox/fake-checkbox.js"></script>

<link href="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css" rel="stylesheet" />
<script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.min.js"></script>