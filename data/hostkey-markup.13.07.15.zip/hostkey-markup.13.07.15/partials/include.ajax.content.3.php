<div class="b-dedicated__hide-block-close js-close">
    <span class="b-icon b-dedicated__hide-block-close-image"></span>
    <span class="b-dedicated__hide-block-close-text">hide</span>
</div>

<div class="b-dedicated__item-content b-dedicated__item-content_padding-top_yes dedicated-item-content dedicated-extra-price">
<div class="b-dedicated__box">
    <h3 class="b-dedicated__title b-dedicated__title_upline_yes">extra price</h3>

    <div class="b-dedicated__description">
        HOSTKEY offers own dedicated and virtual servers in various Datacenters in Moscow, Russia.
        We are first hands for offshore Dedicated servers in Russia since 2008, managing 600+ servers here with 20+
        international resellers. Virtually any server configuration could be provided to our customers. We offer full
        range of modern and stock servers for every task. You could lease Cisco network equipment or collocate your own
        servers in Moscow.
    </div>
</div>

<div class="b-container">

    <div class="dedicated-extra-price__box">
        <table class="dedicated-extra-price__table dedicated-extra-price__table_type_head">
            <tr class="dedicated-extra-price__table-row">
                <td class="dedicated-extra-price__table-cell js-checked">
                    <div class="dedicated-extra-price__table-title">CPU number</div><!--
                    --><label class="b-checkbox-submit b-checkbox-submit_size_70">
                        <span class="b-checkbox-submit__text">1 CPU</span>
                        <input class="js-checked-submit" name="check-01" type="radio"/>
                    </label><!--
                    --><label class="b-checkbox-submit b-checkbox-submit_size_70">
                        <span class="b-checkbox-submit__text">2 CPU</span>
                        <input class="js-checked-submit" name="check-01" type="radio"/>
                    </label>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <div class="dedicated-extra-price__table-title">Sort</div>
                    <select class="table-select__item js-select" name="tbl-select-1" id="tbl-select-1">
                        <option value="1">Price (low -> high)</option>
                        <option value="2">Price (high -> low)</option>
                        <option value="3">New (old -> new</option>
                        <option value="4">New (new -> old</option>
                    </select>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <button class="b-submit dedicated-extra-price__table-submit" type="button">find</button>
                </td>
            </tr>
        </table>
    </div>
    <div class="dedicated-extra-price__box">
        <table class="dedicated-extra-price__table">
            <tr class="dedicated-extra-price__table-row dedicated-extra-price__table-row_title_yes">
                <td class="dedicated-extra-price__table-cell"></td>
                <td class="dedicated-extra-price__table-cell">processor</td>
                <td class="dedicated-extra-price__table-cell">memory</td>
                <td class="dedicated-extra-price__table-cell">hard drive</td>
                <td class="dedicated-extra-price__table-cell">hardware raid</td>
                <td class="dedicated-extra-price__table-cell">vlan</td>
                <td class="dedicated-extra-price__table-cell">free bonus</td>
                <td class="dedicated-extra-price__table-cell">monthly</td>
                <td class="dedicated-extra-price__table-cell dedicated-extra-price__table-cell_red_yes">price will change after:</td>
            </tr>
            <tr class="dedicated-extra-price__table-row">
                <td class="dedicated-extra-price__table-cell"><span class="b-icon b-flag b-flag_country_nether"></span></td>
                <td class="dedicated-extra-price__table-cell">
                    <div class="dedicated-extra-price__text">
                        Core2Duo E6320 1.86 GHz (2 core)
                    </div>
                    <div class="b-range">
                        <span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item"></span>
                    </div>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="dedicated-extra-price__text">128 GB</span>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="dedicated-extra-price__text">2x500Gb SATA</span>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="b-icon dedicated-extra-price__icon-good"></span>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="dedicated-extra-price__text">100 Mbps</span>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    20 IP, traffic,
                    cPanel, Windows,
                    VPS, premium SLA,
                    super backup
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <a class="b-submit dedicated-item-content__submit" href="#">1650.65</a>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <div class="black-sale__slider-item-timer" id="js-countdown-6"></div>
                </td>
            </tr>
            <tr class="dedicated-extra-price__table-row">
                <td class="dedicated-extra-price__table-cell"><span class="b-icon b-flag"></span></td>
                <td class="dedicated-extra-price__table-cell">
                    <div class="dedicated-extra-price__text">
                        Core2Duo E6320 1.86 GHz (2 core)
                    </div>
                    <div class="b-range">
                        <span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span>
                    </div>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="dedicated-extra-price__text">128 GB</span>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="dedicated-extra-price__text">2x500Gb SATA</span>
                </td>
                <td class="dedicated-extra-price__table-cell"></td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="dedicated-extra-price__text">1 Gbps</span>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    20 IP, traffic,
                    cPanel, Windows
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <a class="b-submit dedicated-item-content__submit" href="#">1650.65</a>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <div class="black-sale__slider-item-timer" id="js-countdown-7"></div>
                </td>
            </tr>
            <tr class="dedicated-extra-price__table-row">
                <td class="dedicated-extra-price__table-cell"><span class="b-icon b-flag b-flag_country_nether"></span></td>
                <td class="dedicated-extra-price__table-cell">
                    <div class="dedicated-extra-price__text">
                        Core2Duo E6320 1.86 GHz (2 core)
                    </div>
                    <div class="b-range">
                        <span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item b-range__item_type_green"></span><!--
                        --><span class="b-range__item"></span><!--
                        --><span class="b-range__item"></span><!--
                        --><span class="b-range__item"></span>
                    </div>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="dedicated-extra-price__text">24 GB</span>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="dedicated-extra-price__text">2x500Gb SATA</span>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="b-icon dedicated-extra-price__icon-good"></span>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <span class="dedicated-extra-price__text">None</span>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    20 IP, traffic,
                    cPanel, Windows
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <a class="b-submit dedicated-item-content__submit" href="#">1650.65</a>
                </td>
                <td class="dedicated-extra-price__table-cell">
                    <div class="black-sale__slider-item-timer" id="js-countdown-8"></div>
                </td>
            </tr>
        </table>
    </div>

    <div class="dedicated-extra-price__box dedicated-extra-price__box_last_yes">
        <a class="b-submit dedicated-extra-price__banner" href="#">
            SHOW EXTRA PRICE SERVERS IN RUSSIAN DATA CENTER /<br>
            starst from €15.99/month
        </a>
    </div>

</div>

</div>

<script>
    $('#js-countdown-6').timeTo({
        seconds: 7660,
        displayCaptions: true,
        captionSize: 8
    });
    $('#js-countdown-7').timeTo({
        seconds: 3660,
        displayCaptions: true,
        captionSize: 8
    });
    $('#js-countdown-8').timeTo({
        seconds: 5660,
        displayCaptions: true,
        captionSize: 8
    });
</script>