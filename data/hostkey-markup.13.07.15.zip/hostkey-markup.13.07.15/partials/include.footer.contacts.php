<footer class="b-footer b-footer_contacts-page_yes">

        <div class="b-footer__wrapper">
            <div class="b-footer__dev">
                <p class="b-footer__text">© 2015, HOSTKEY Ltd., All Rights Reserved</p>
                <p class="b-footer__text">MADE IN <a class="b-link b-footer__link" href="#">SUNERA</a></p>
            </div>
            <div class="b-icon b-footer__triangle" onclick="$.scrollTo(0, 1000)"></div>
        </div>

</footer>