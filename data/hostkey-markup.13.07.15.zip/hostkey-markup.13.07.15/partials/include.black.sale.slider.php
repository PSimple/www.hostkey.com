<div class="black-sale__slider js-carousel">
    <div class="black-sale__slider-item">
        <a class="black-sale__link" href="#">
            <div class="black-sale__slider-item-price">€ 130.65</div>
            <div class="black-sale__slider-item-text black-sale__slider-item-text_red_yes">Price will change after:</div>
            <div class="black-sale__slider-item-timer" id="js-countdown-1"></div>
            <div class="black-sale__slider-item-text">Processor: Core2Duo
                E6320 1.86 GHz (2 core)</div>
            <div class="black-sale__slider-item-text">Memory: 128 Gb</div>
            <div class="black-sale__slider-item-text">Hard drive: 2x500Gb SATA</div>
            <div class="black-sale__slider-item-text">Vlan: 1 Gbps</div>
            <div class="black-sale__slider-item-text black-sale__slider-item-text_red_yes">Free bonus: traffic,
                cPanel, Windowssuper backup</div>
            <div class="black-sale__slider-item-order">order</div>
        </a>
    </div>
    <div class="black-sale__slider-item">
        <a class="black-sale__link" href="#">
            <div class="black-sale__slider-item-price">€ 130.65</div>
            <div class="black-sale__slider-item-text black-sale__slider-item-text_red_yes">Price will change after:</div>
            <div class="black-sale__slider-item-timer" id="js-countdown-2"></div>
            <div class="black-sale__slider-item-text">Processor: Core2Duo
                E6320 1.86 GHz (2 core)</div>
            <div class="black-sale__slider-item-text">Memory: 128 Gb</div>
            <div class="black-sale__slider-item-text">Hard drive: 2x500Gb SATA</div>
            <div class="black-sale__slider-item-text">Vlan: 1 Gbps</div>
            <div class="black-sale__slider-item-text black-sale__slider-item-text_red_yes">
                Free bonus: 20 IP, traffic,
                cPanel, Windows, VPS, premiumSLA, super backup
            </div>
            <div class="black-sale__slider-item-order">order</div>
        </a>
    </div>
    <div class="black-sale__slider-item">
        <a class="black-sale__link" href="#">
            <div class="black-sale__slider-item-price">€ 130.65</div>
            <div class="black-sale__slider-item-text black-sale__slider-item-text_red_yes">Price will change after:</div>
            <div class="black-sale__slider-item-timer" id="js-countdown-3"></div>
            <div class="black-sale__slider-item-text">Processor: Core2Duo
                E6320 1.86 GHz (2 core)</div>
            <div class="black-sale__slider-item-text">Memory: 128 Gb</div>
            <div class="black-sale__slider-item-text">Hard drive: 2x500Gb SATA</div>
            <div class="black-sale__slider-item-text">Vlan: 1 Gbps</div>
            <div class="black-sale__slider-item-order">order</div>
        </a>
    </div>
    <div class="black-sale__slider-item">
        <a class="black-sale__link" href="#">
            <div class="black-sale__slider-item-price">€ 130.65</div>
            <div class="black-sale__slider-item-text black-sale__slider-item-text_red_yes">Price will change after:</div>
            <div class="black-sale__slider-item-timer" id="js-countdown-4"></div>
            <div class="black-sale__slider-item-text">Processor: Core2Duo
                E6320 1.86 GHz (2 core)</div>
            <div class="black-sale__slider-item-text">Memory: 128 Gb</div>
            <div class="black-sale__slider-item-text">Hard drive: 2x500Gb SATA</div>
            <div class="black-sale__slider-item-text">Vlan: 1 Gbps</div>
            <div class="black-sale__slider-item-text black-sale__slider-item-text_red_yes">Free bonus: traffic,
                cPanel, Windowssuper backup</div>
            <div class="black-sale__slider-item-order">order</div>
        </a>
    </div>
    <div class="black-sale__slider-item">
        <a class="black-sale__link" href="#">
            <div class="black-sale__slider-item-price">€ 130.65</div>
            <div class="black-sale__slider-item-text black-sale__slider-item-text_red_yes">Price will change after:</div>
            <div class="black-sale__slider-item-timer" id="js-countdown-5"></div>
            <div class="black-sale__slider-item-text">Processor: Core2Duo
                E6320 1.86 GHz (2 core)</div>
            <div class="black-sale__slider-item-text">Memory: 128 Gb</div>
            <div class="black-sale__slider-item-text">Hard drive: 2x500Gb SATA</div>
            <div class="black-sale__slider-item-text">Vlan: 1 Gbps</div>
            <div class="black-sale__slider-item-text black-sale__slider-item-text_red_yes">Free bonus: traffic,
                cPanel, Windowssuper backup</div>
            <div class="black-sale__slider-item-order">order</div>
        </a>
    </div>
</div>