$('#js-countdown-1').timeTo({
    seconds: 7660,
    displayCaptions: true,
    captionSize: 12
});
$('#js-countdown-2').timeTo({
    seconds: 8660,
    displayCaptions: true,
    captionSize: 12
});
$('#js-countdown-3').timeTo({
    seconds: 3760,
    displayCaptions: true,
    captionSize: 12
});
$('#js-countdown-4').timeTo({
    seconds: 13760,
    displayCaptions: true,
    captionSize: 12
});
$('#js-countdown-5').timeTo({
    seconds: 4566,
    displayCaptions: true,
    captionSize: 12
});